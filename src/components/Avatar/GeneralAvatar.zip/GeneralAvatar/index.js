import GeneralAvatar from './GeneralAvatar';
import './GeneralAvatar.scss';

export default GeneralAvatar;
